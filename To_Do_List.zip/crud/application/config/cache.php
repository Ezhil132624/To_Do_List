<?php
$config['host'] = '127.0.0.1';
$config['port'] = 6379;
$config['password'] = '';
$config['timeout'] = 0;
$config['adapter'] = 'redis';
$config['backup'] = 'file';
?>